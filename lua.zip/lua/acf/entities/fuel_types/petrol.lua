local FuelTypes = ACF.Classes.FuelTypes


FuelTypes.Register("Petrol", {
	Name	= "Petrol Fuel",
	Density	= 0.832,
})
