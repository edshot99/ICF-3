local FuelTypes = ACF.Classes.FuelTypes


FuelTypes.Register("Diesel", {
	Name	= "Diesel Fuel",
	Density	= 0.745,
})
