DEFINE_BASECLASS("acf_base_scalable")

ENT.PrintName     = "ACF Fuel Tank"
ENT.WireDebugName = "ACF Fuel Tank"
ENT.PluralName    = "ACF Fuel Tanks"
ENT.IsACFFuelTank = true

cleanup.Register("acf_fueltank")