DEFINE_BASECLASS("base_anim")

AddCSLuaFile()
AddCSLuaFile("cl_init.lua")