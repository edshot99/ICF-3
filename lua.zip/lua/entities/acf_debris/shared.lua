DEFINE_BASECLASS("base_anim")

ENT.PrintName = "Fireball"
ENT.RenderGroup = RENDERGROUP_OTHER