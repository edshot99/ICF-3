DEFINE_BASECLASS("acf_base_simple")

ENT.PrintName     = "ACF Gearbox"
ENT.WireDebugName = "ACF Gearbox"
ENT.PluralName    = "ACF Gearboxes"
ENT.IsACFGearbox  = true

cleanup.Register("acf_gearbox")
