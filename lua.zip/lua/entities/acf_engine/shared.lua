DEFINE_BASECLASS("acf_base_simple")

ENT.PrintName     = "ACF Engine"
ENT.WireDebugName = "ACF Engine"
ENT.PluralName    = "ACF Engines"
ENT.IsACFEngine   = true

cleanup.Register("acf_engine")
