DEFINE_BASECLASS("base_wire_entity")

ENT.PrintName     = "Simple ACF Base Entity"
ENT.WireDebugName = "Simple ACF Base Entity"
ENT.PluralName    = "Simple ACF Base Entities"
ENT.IsACFEntity   = true
