DEFINE_BASECLASS("acf_base_simple")

ENT.Type	= "anim"
ENT.CanTool	= function() return false end
ENT.CanProperty	= function() return false end