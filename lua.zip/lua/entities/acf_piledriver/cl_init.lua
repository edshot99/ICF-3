include("shared.lua")

language.Add("Cleanup_acf_piledriver", "ACF Piledrivers")
language.Add("Cleaned_acf_piledriver", "Cleaned up all ACF Piledrivers")
