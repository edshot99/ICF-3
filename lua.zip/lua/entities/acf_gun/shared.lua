DEFINE_BASECLASS("acf_base_scalable")

ENT.PrintName     = "ACF Weapon"
ENT.WireDebugName = "ACF Weapon"
ENT.PluralName    = "ACF Weapons"
ENT.IsACFWeapon      = true

cleanup.Register("acf_gun")
cleanup.Register("acf_smokelauncher")
