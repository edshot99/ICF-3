DEFINE_BASECLASS("acf_base_scalable")

ENT.PrintName      = "ACF Ammo Crate"
ENT.WireDebugName  = "ACF Ammo Crate"
ENT.PluralName     = "ACF Ammo Crates"
ENT.IsACFAmmoCrate = true

cleanup.Register("acf_ammo")
