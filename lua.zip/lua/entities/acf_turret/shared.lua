DEFINE_BASECLASS("acf_base_scalable")

ENT.PrintName     	= "ACF Turret Drive"
ENT.WireDebugName 	= "ACF Turret Drive"
ENT.PluralName    	= "ACF Turret Drives"
ENT.IsACFEntity   	= true
ENT.IsACFTurret		= true

cleanup.Register("acf_turret")