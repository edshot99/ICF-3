DEFINE_BASECLASS("acf_base_scalable")

include("shared.lua")

language.Add("Cleanup_acf_turret_motor", "ACF Turret Motors")
language.Add("Cleaned_acf_turret_motor", "Cleaned up all ACF turret motors!")
language.Add("SBoxLimit__acf_turret_motor", "You've reached the ACF turret motors limit!")