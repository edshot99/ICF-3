DEFINE_BASECLASS("acf_base_scalable")

ENT.PrintName     	= "ACF Turret Motor"
ENT.WireDebugName 	= "ACF Turret Motor"
ENT.PluralName    	= "ACF Turret Motors"
ENT.IsACFEntity   	= true
ENT.IsACFMotor		= true

cleanup.Register("acf_turret_motor")