DEFINE_BASECLASS("acf_base_simple")

ENT.PrintName     	= "ACF Ballistic Computer"
ENT.WireDebugName 	= "ACF Ballistic Computer"
ENT.PluralName    	= "ACF Ballistic Computers"
ENT.IsACFEntity   	= true

cleanup.Register("acf_turret_computer")