DEFINE_BASECLASS("acf_base_simple")

include("shared.lua")

language.Add("Cleanup_acf_turret_computer", "ACF Ballistic Computers")
language.Add("Cleaned_acf_turret_computer", "Cleaned up all ACF ballistic computers!")
language.Add("SBoxLimit__acf_turret_computer", "You've reached the ACF ballistic computers limit!")