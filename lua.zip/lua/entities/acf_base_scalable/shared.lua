DEFINE_BASECLASS("base_scalable")

ENT.PrintName     = "Scalable ACF Base Entity"
ENT.WireDebugName = "Scalable ACF Base Entity"
ENT.PluralName    = "Scalable ACF Base Entities"
ENT.IsACFEntity   = true