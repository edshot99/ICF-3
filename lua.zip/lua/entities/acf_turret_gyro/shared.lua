DEFINE_BASECLASS("acf_base_simple")

ENT.PrintName     	= "ACF Turret Gyro"
ENT.WireDebugName 	= "ACF Turret Gyro"
ENT.PluralName    	= "ACF Turret Gyros"
ENT.IsACFEntity   	= true
ENT.IsACFGyro		= true

cleanup.Register("acf_turret_gyro")