DEFINE_BASECLASS("acf_base_simple")

include("shared.lua")

language.Add("Cleanup_acf_turret_gyro", "ACF Turret Gyroscopes")
language.Add("Cleaned_acf_turret_gyro", "Cleaned up all ACF turret gyroscopes!")
language.Add("SBoxLimit__acf_turret_gyro", "You've reached the ACF turret gyroscope limit!")